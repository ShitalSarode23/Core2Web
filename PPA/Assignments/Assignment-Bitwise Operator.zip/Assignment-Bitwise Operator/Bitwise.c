

#include<stdio.h>
void main(){

	printf("%d\n",15&19);	//3
	printf("%d\n",7|21);	//23
	printf("%d\n",65&29);	//1

	int x=10;
	printf("%d\n",x<<4);	//160

	printf("%d\n",53&19);	//17
	printf("%d\n",23|77);	//95

	int a=58;
	printf("%d\n",a<<3);	//464

	printf("%d\n",45|33);	//45
	
	int s=95;
	printf("%d\n",s<<2);	//380

	int p=18;
	printf("%d\n",p<<5);	//576

}
