

#include<stdio.h>
void main(){

	int num=20;
	if(num>20){

		printf("num is greater than 20\n");		//if num is greater than 20 printf will execute
	}
	printf("num:%d\n",num);					//here num is not greater than 20 thats why if loop is not executing
}
