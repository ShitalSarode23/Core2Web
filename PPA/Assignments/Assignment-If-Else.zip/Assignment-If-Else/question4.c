

#include<stdio.h>
void main(){
	bool val=false, var=true;
	if(val);{
		printf("true\n");
	}
	if(var){
		printf("false\n");
	}

}
