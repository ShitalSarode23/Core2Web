


#include<stdio.h>
void main(){

	int num;
	printf("Enter Number");
	scanf("%d",&num);
	
	if(num>=25 && num<=50)

		printf("Number is in range 25 to 50\n");
	else
		printf("%d doesnt belong in the range 25 to 50\n",num);



}
