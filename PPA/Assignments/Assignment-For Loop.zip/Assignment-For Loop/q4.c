

#include<stdio.h>

void main(){

	for(int i=1;i<=50;i++){

		if(50%i==0)
			printf("%d\n",i);

	}

}
