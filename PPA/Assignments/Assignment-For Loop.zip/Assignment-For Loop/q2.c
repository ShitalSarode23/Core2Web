

#include<stdio.h>
void main(){

	for(int i=20;i<=40;i++){

		if(i%2!=0)
			printf("%d\n",i);
	}
}
