

#include<stdio.h>

void main(){

	for(int i=65;i<=90;i++){

		printf("%c = %c,",i,i+32);
	}

	printf("\n");
}
