
#include<stdio.h>

void main(){

	for(int i=1;i<=128;i++){

		printf("%c = %d\t",i,i);

	}

	printf("\n");
}
