

#include<stdio.h>
void main(){

	int x=10;
	float y=25.6f;
	double d=60.320;
	char ch='A';
	//void v=30;		//Error:variable or feild declared void

	printf("%d\n",x);
	printf("%f\n",y);
	printf("%f\n",d);
	printf("%c\n",ch);
	//printf("%d\n",v);


}


