


#include<stdio.h>
void main(){

	printf("%ld\n",sizeof(int));
	printf("%ld\n",sizeof(float));
	printf("%ld\n",sizeof(double));
	printf("%ld\n",sizeof(char));
	printf("%ld\n",sizeof(void));


}
