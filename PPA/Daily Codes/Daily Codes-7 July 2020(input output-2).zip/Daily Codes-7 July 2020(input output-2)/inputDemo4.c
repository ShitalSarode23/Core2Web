

#include<stdio.h>
void main(){

	char ch1,ch2;

	printf("Enter two characters :\n");
	scanf("%c %c",&ch1,&ch2);		//A a

	printf("%c\n%c\n",ch1,ch2);		//A a



}
