

#include<stdio.h>
void main(){

	float val1,val2;

	printf("Enter Two values for float\n");
	scanf("%f %f",&val1,&val2);

	printf("Val1 = %f\nval2 = %f\n",val1,val2);


}


