

#include<stdio.h>
void main(){

	int x;
	float f;
	char ch;

	printf("Enter value for int,float,char\n");
	scanf("%d %f %c",&x,&f,&ch);

	printf("int value = %d\nfloat value = %f\nchar value = %c\n",x,f,ch);	//10 20.5




}
