

#include<stdio.h>
void main(){

	int x;
	float f;
	char ch;


	printf("Enter value for int\n");
	scanf("%d",&x);

	printf("Enter value for float\n");
	scanf("%f",&f);

	printf("Enter value for char\n");
	scanf(" %c",&ch);

	printf("int value = %d\n",x);
	printf("float value = %f\n",f);
	printf("char value = %c\n",ch);		




}
