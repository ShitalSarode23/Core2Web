

#include<stdio.h>
void main(){

	printf("%d\n",10&15);		//10

	printf("%d\n",4|5);		//5

	printf("%d\n",10<<2);		//40

	printf("%d\n",15<<3);		//120

	printf("%d\n",35>>3);		//4

	printf("%d\n",220>>4);		//13


}
