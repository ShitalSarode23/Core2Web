

#include<stdio.h>
void main(){

	int x=45,y=12,ans;
	ans=x^y;
	printf("%d\n",ans);	//33



}
