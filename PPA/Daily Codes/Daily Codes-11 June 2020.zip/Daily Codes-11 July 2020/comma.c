

#include<stdio.h>
void main(){

	//int x=10,20,30,40,50;
	//printf("%d\n",x);		//error:expected identifier before numeric constant

	int y=(10,20,30,40,50);
	printf("%d\n",y);		//50

}
