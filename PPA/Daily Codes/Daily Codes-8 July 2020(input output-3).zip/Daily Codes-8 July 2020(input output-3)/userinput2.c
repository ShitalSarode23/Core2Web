

#include<stdio.h>
void main(){

	int x,y;
	char ch;
	printf("Enter two values\n");
	scanf("%d %d",&x,&y);

	if(x = y)
		printf("True\n");
	printf("Out of if\n");

}
