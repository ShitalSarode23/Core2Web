

#include<stdio.h>
void main(){

	int x,y;

	printf("Enter two values\n");
	scanf("%d %d",&x,&y);

	if(x>y)
		printf("x is greater\n");
	printf("Out of if\n");

}
