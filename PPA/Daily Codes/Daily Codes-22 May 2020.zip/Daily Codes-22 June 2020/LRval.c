



#include<stdio.h>
void main(){

	int x=10;
	int y=x;
	//int 10=y;		//Error :expected identifire before numerivc constant

	printf("%d %d\n",x,y);
	
	char ch='A';
	char var=ch;

	printf("%d %d\n",ch,var);

	printf("%c %c\n",ch,var);



}
