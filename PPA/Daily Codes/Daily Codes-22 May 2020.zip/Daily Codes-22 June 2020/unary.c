

#include<stdio.h>
void main(){

	int x=10;

	printf("%d\n",x);	//10
	printf("%d\n",++x);	//11
	printf("%d\n",x++);	//11
	printf("%d\n",x);	//12

}
