


#include<stdio.h>
void main(){

	char ch='d';

	switch(ch){

		case 'A':
			printf("Case-A\n");
			break;
		case 'B':
			printf("Case-B\n");
			break;
		case 'C':
			printf("Case-C\n");
			break;
		default :
			printf("Default Case\n");
			break;
		case 'D':
			printf("Case-D\n");
			break;

	}




}
