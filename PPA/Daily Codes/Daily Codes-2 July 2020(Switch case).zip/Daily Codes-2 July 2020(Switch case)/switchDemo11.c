


#include<stdio.h>
void main(){

	int a=10;

	switch(a){


		case 9:{
			int x=10;
			int y=20;
			printf("%d\n",x+y);
		       }
			break;
		case 10:
			{
			int x=10;
			int y=20;
			printf("%d\n",x-y);
			}
			break;
	}


}
