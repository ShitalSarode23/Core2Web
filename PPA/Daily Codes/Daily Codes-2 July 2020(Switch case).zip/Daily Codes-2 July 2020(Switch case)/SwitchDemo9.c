


#include<stdio.h>
void main(){

	int a=65;

	switch(a){

		case 'A':
			printf("Case-A\n");
			break;
		case 'B':
			printf("Case-B\n");
			break;
		case '6':
			printf("Case-65\n");
			break;

	}




}
