


#include<stdio.h>
void main(){

	char ch='d';

	switch(ch){

		default :
			printf("Default Case\n");
		case 'A':
			printf("Case-A\n");
			break;
		case 'B':
			printf("Case-B\n");
			break;
		case 'C':
			printf("Case-C\n");
			break;
		case 'D':
			printf("Case-D\n");
			break;

	}




}
