

#include<stdio.h>
void main(){

	int marks = 93;

	if(marks>90){
		printf("Laptop\n");
		printf("Bike\n");
		printf("Watch\n");
	}
	printf("New T-shirts\n");

	 marks = 89;

	if(marks>90){
		printf("Laptop\n");
		printf("Bike\n");
		printf("Watch\n");
	}
	printf("New T-shirts\n");

}
