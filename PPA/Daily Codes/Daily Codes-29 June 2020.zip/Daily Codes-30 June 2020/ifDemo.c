

#include<stdio.h>
void main(){

	int a=5;
	int b=10;
	int c=0;

	if(a<10)	//false
		printf("10 is greater\n");
	
	if(a &&b)				//1
		printf("Core2web\n");		//Core2web
	if(b && c)				//0
		printf("Biencaps\n");		//blank
	if(b || c)				//1
		printf("Amazon\n");		//Amazon





}
