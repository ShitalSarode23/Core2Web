

#include<stdio.h>
void main(){

	
	int  marks = 89;

	if(marks>90);	//Null Statement
	{
		printf("Laptop\n");
		printf("Bike\n");
		printf("Watch\n");
	}
	printf("New T-shirts\n");

}
