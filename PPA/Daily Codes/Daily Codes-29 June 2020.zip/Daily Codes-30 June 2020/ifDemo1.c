

#include<stdio.h>
void main(){

	int a=10;

	if(a==10)
		printf("Equal\n");
		printf("End of if\n");

	if(a!=10)
		printf("Equal\n");
		printf("End of if\n");



}
