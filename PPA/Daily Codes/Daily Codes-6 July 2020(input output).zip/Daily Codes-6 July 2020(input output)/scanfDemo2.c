

#include<stdio.h>
void main(){

	int a,b;

	printf("Enter Number for a and b :\n");
	scanf("%d %d",&a,&b);

	printf("a = %d\nb = %d\n",a,b);




}
