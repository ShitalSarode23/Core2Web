

#include<stdio.h>
void main(){

	int a,b,ans;

	printf("Enter Number for a and b :\n");
	scanf("%d %d",&a,&b);

	ans = a+b;

	printf("Ans = %d\n",ans);


}
