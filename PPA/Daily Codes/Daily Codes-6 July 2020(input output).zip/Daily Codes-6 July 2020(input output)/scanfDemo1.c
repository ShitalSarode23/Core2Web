

#include<stdio.h>
void main(){

	int a,b;

	printf("Enter Number for a:\n");
	scanf("%d",&a);

	printf("Enter Number for b:\n");
	scanf("%d",&b);

	printf("a = %d\n",a);
	printf("b = %d\n",b);




}
