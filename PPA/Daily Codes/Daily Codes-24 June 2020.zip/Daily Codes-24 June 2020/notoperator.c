

#include<stdio.h>
void main(){

	int a=35;

	printf("%d\n",~(a));		//-36
	printf("%d\n",~(20));		//-21
	printf("%d\n",~(-20));		//19
	printf("%d\n",~(-36));		//35
	printf("%d\n",~(13));		//-14

	printf("%d\n",~(-13));		//12


}
