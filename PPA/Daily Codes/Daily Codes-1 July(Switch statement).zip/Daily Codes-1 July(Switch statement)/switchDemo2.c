

#include<stdio.h>
void main(){

	int a=1;
	
	switch(a){
		printf("Inside switch\n");
	}
	printf("outside switch\n");
	
}
