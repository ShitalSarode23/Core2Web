//matching case

#include<stdio.h>
void main(){

	int a=2;
	
	switch(a){

	case 1:
		printf("Inside switch\n");
	}
	printf("outside switch\n");
	
}
