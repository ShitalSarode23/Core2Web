

#include<stdio.h>
void main(){

	int a=1;
	char ch='S';
	float f=20.0;

	switch(f){


		case 20.0:
			printf("float value\n");
			break;
	}

	printf("outside switch\n");

}
