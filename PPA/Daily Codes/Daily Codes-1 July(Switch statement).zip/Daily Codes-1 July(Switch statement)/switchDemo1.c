

#include<stdio.h>
void main(){

	int a=1;
	//Without Expression and case
	switch(){		//error

	}
	//without case
	switch(a){		//No error


	}


}
