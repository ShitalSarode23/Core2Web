

#include<stdio.h>
void main(){

	int a=65;

	switch(a){


		case 'B':
			printf("Character A\n");
			break;
	}
	printf("Outside switch\n");


}
