

#include<stdio.h>

void main(){

	int i = 97;
	int c;
	for(; i<=122;){

		printf("%c %d\n",i,c);
		c++;
		i++;
	}


}
