

#include<stdio.h>

void main(){

	int i = 65;

	while(i<=90){

		printf("%c\n",i);
		i++;
	}


}
