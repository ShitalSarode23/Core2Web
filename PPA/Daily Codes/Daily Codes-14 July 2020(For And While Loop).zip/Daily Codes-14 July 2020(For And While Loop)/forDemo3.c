

#include<stdio.h>

void main(){

	int i = 97;

	for(;i<=122;i++);{

		printf("In for loop\n");
		printf("%c\n",i);
	}
}
