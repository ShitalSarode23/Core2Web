

#include<stdio.h>

void main(){

	for(int i=1;i<=10;i++){

		if(i%2==0)
			printf("Even = %d\n",i);

		else
			printf("Odd = %d\n",i);
	}


}
