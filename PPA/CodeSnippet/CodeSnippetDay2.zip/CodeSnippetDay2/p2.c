

#include<stdio.h>
void main(){

	int i = 3, j;

	j=i++;			//3

	printf("%d %d\n",i,j);	//4 3




}
