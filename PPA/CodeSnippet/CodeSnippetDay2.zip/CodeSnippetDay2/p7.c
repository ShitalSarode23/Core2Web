


#include<stdio.h>
void main(){

	int x = 12 ,y =7,z;
	z= x!=4 || y==2;		//1 || not check

	printf("Z = %d\n",z);		//1




}
