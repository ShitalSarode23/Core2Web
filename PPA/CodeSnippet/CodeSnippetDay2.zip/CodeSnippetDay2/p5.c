

#include<stdio.h>
void main(){

	printf("%x\n",2<<2);		// 0010 << 2=1000 = 8




}
