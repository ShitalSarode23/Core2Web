

#include<stdio.h>
void main(){

	int x= 4,y,z;

	y = --x;			//3
	z = x--;			//3
	printf("%d %d %d\n",x,y,z);	//2 3 3



}
