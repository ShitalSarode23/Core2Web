

#include<stdio.h>
void main(){

	int i = 10,j = 10 ,k;
	k = ++i + j++;				//i + j
						//11 + 10=21 (i=11,j=11)
	printf("%d %d %d\n",i,j,k);		//11 11 21







}
